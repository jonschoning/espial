import{C as f,dd as e,o as t,oc as n,od as i,ta as o,va as r}from"../chunk-C2VZJJ3O.js";var c=f(o),m=t(r),s=function(p){return c(function(a){return m(n(e(a)))})(i(p))};export{s as logoutE};
//# sourceMappingURL=index.js.map
